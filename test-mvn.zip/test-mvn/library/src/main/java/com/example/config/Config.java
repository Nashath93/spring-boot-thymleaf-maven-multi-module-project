package com.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.service.Service;
import com.example.service.UserService;

@Configuration
public class Config {

	@Bean
	public Service service(){
		return new Service();
	}
	
	@Bean
	public UserService userService(){
		return new UserService();
	}
	
	
}
