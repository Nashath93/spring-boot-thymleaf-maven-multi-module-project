package com.example.service;

import org.springframework.stereotype.Component;

@Component
public class Service {

	private String message = "Hello World";
	
	public Service() {
	}
	
	public Service(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
