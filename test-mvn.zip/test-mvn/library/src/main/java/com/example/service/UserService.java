package com.example.service;

import org.springframework.stereotype.Component;

@Component
public class UserService {

	private String welcomeMessage = "Hello from user service class";

	public UserService() {

	}
	
	public UserService(String welcomeMessage) {
		this.welcomeMessage = welcomeMessage;
	}
	
	public String getWelcomeMessage() {
		return welcomeMessage;
	}

	public void setWelcomeMessage(String welcomeMessage) {
		this.welcomeMessage = welcomeMessage;
	}
	
	
	
	
}
