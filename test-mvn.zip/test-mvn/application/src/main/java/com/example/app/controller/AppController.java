package com.example.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.config.Config;
import com.example.service.Service;
import com.example.service.UserService;

@Controller
@Import(Config.class)
public class AppController {

	@Autowired
	private Service service;
	
	@Autowired
	private UserService userService;

	public Service getService() {
		return service;
	}

	public void setService(Service service) {
		this.service = service;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping(value="/")
	public String homePage(ModelMap model){
		
		model.addAttribute("message", this.service.getMessage());
		model.addAttribute("welcomeMessage", this.userService.getWelcomeMessage());
		return "index";
	}
	
	
	

}
